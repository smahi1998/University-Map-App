package edu.okcu.mapdemo

import android.app.Dialog
import android.graphics.Bitmap
import android.graphics.Canvas
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.RadioGroup
import android.widget.TextView
import androidx.core.content.res.ResourcesCompat

import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import edu.okcu.mapdemo.databinding.ActivityMapsBinding
import android.content.Intent
import com.google.android.material.bottomnavigation.BottomNavigationView

data class MarkerInfo(val imageResId: Int, val title: String, val content: String)


class MapsActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var mMap: GoogleMap
    private lateinit var binding: ActivityMapsBinding
    private lateinit var radioGroup: RadioGroup

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMapsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val bottomNavigationView = findViewById<BottomNavigationView>(R.id.bottom_navigation)
        bottomNavigationView.setOnNavigationItemSelectedListener { item ->
            when (item.itemId) {
                R.id.navigation_home -> {
                    // Navigate to HomeActivity
                    val intent = Intent(this, MapsActivity::class.java)
                    startActivity(intent)
                    true
                }
                R.id.navigation_dashboard -> {
                    // Navigate to DashboardActivity
                    val intent = Intent(this, BuildingListActivity::class.java)
                    startActivity(intent)
                    true
                }

                else -> false
            }
        }

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)

        radioGroup = binding.radioGroup
        radioGroup.setOnCheckedChangeListener { _, itemId: Int ->
            when (itemId) {
                R.id.buttonNormal -> {
                    mMap.mapType = GoogleMap.MAP_TYPE_NORMAL
                }

                R.id.buttonSat -> {
                    mMap.mapType = GoogleMap.MAP_TYPE_SATELLITE
                }

                R.id.buttonHybrid -> {
                    mMap.mapType = GoogleMap.MAP_TYPE_HYBRID
                }

                R.id.buttonTerrain -> {
                    mMap.mapType = GoogleMap.MAP_TYPE_TERRAIN
                }
            }
        }

    }

    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap

        mMap.mapType = GoogleMap.MAP_TYPE_NORMAL

        // Add a marker in Sydney and move the camera
        val ocu = LatLng(35.49570, -97.54103)
        val marker = MarkerOptions()
        marker.title("Oklahoma City University")
        marker.snippet("Go Stars!!!!")

        marker.position(ocu)

        mMap.addMarker(marker)

        mMap.moveCamera(CameraUpdateFactory.zoomTo(16f))
        mMap.moveCamera(CameraUpdateFactory.newLatLng(ocu))

        // UI Settings
        mMap.uiSettings.isZoomControlsEnabled = true
        mMap.uiSettings.isMapToolbarEnabled = false

        var customMarker = MarkerOptions()
        var customLocation = LatLng(35.49384, -97.54358)
        customMarker.title("Sarkeys Science and Math (SSM)")
        customMarker.position(customLocation)
        var image: Bitmap? = getImage(R.drawable.logo)
        customMarker.icon(image?.let { BitmapDescriptorFactory.fromBitmap(it) })
        val ssmMarker = mMap.addMarker(customMarker)
        ssmMarker?.tag = MarkerInfo(R.drawable.ssm_image, "Sarkeys Science and Math", "Computer Science Student Building")

        var customMarker1 = MarkerOptions()
        var customLocation1 = LatLng(35.49435467472705, -97.54207939672075)
        customMarker1.title("Gold Star Memorial Building")
        customMarker1.position(customLocation1)
        var image1: Bitmap? = getImage(R.drawable.logo)
        customMarker1.icon(image1?.let { BitmapDescriptorFactory.fromBitmap(it) })
        val goldStarMarker = mMap.addMarker(customMarker1)
        goldStarMarker?.tag = MarkerInfo(R.drawable.gold_star_image, "Gold Star Memorial Building", "Go Star!!!!")

        var customMarker2 = MarkerOptions()
        var customLocation2 = LatLng(35.49396154268731, -97.54270307751358)
        customMarker2.title("Walkerhall")
        customMarker2.position(customLocation2)
        var image2: Bitmap? = getImage(R.drawable.logo)
        customMarker2.icon(image2?.let { BitmapDescriptorFactory.fromBitmap(it) })
        val walkerhall = mMap.addMarker(customMarker2)
        walkerhall?.tag = MarkerInfo(R.drawable.walker, "Walker Hall", "Freshmen Dorm")

        var customMarker3 = MarkerOptions()
        var customLocation3 = LatLng(35.49427327285289, -97.53967215150321)
        customMarker3.title("Administration")
        customMarker3.position(customLocation3)
        var image3: Bitmap? = getImage(R.drawable.logo)
        customMarker3.icon(image3?.let { BitmapDescriptorFactory.fromBitmap(it) })
        val Administration = mMap.addMarker(customMarker3)
        Administration?.tag = MarkerInfo(R.drawable.adm, "Administration Building", "Admission stuff")

        mMap.setOnMarkerClickListener { marker ->
            val tag = marker.tag as? MarkerInfo
            tag?.let {
                showImageDialog(it.imageResId, it.title, it.content)
            }
            true
        }
    }



    private fun getImage(resourceId: Int): Bitmap? {
        var bitmap: Bitmap? = null
        var drawable = ResourcesCompat.getDrawable(resources, resourceId, null)
        if (drawable != null) {
            bitmap = Bitmap.createBitmap(150, 150, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)
            drawable.setBounds(0, 0, canvas.width, canvas.height)
            drawable.draw(canvas)
        }

        return bitmap
    }


    private fun showImageDialog(imageResId: Int, title: String, content: String) {
        val dialog = Dialog(this)
        dialog.setContentView(R.layout.image_dialog)
        val imageView = dialog.findViewById<ImageView>(R.id.dialogImage)
        imageView.setImageResource(imageResId)
        val dialogTitle = dialog.findViewById<TextView>(R.id.dialogTitle)
        dialogTitle.text = title
        val dialogContent = dialog.findViewById<TextView>(R.id.dialogContent)
        dialogContent.text = content
        dialog.show()


    }
}
