package edu.okcu.mapdemo

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView



class BuildingListActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_building_list)

        val recyclerView = findViewById<RecyclerView>(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)

        val buildings = listOf(
            Building("Sarkeys Science and Math (SSM)", "Details about SSM", R.drawable.ssm_image),
            Building("Gold Star Memorial Building", "Details about Gold Star", R.drawable.gold_star_image),
            Building("Administration Buiding", "Offices:Student Affairs", R.drawable.adm),
            Building("Walker Building","Details about Walker ",R.drawable.walker)
        )


        val adapter = BuildingAdapter(buildings) { building ->
            val intent = Intent(this, BuildingDetailActivity::class.java)
            intent.putExtra("BUILDING_NAME", building.name)
            intent.putExtra("BUILDING_DETAILS", building.details)
            intent.putExtra("BUILDING_IMAGE", building.imageResId)
            startActivity(intent)
        }

        recyclerView.adapter = adapter
    }
}
