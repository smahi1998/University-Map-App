package edu.okcu.mapdemo

import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class BuildingDetailActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_building_detail)

        val buildingImage = findViewById<ImageView>(R.id.buildingImage)
        val buildingName = findViewById<TextView>(R.id.buildingName)
        val buildingDetails = findViewById<TextView>(R.id.buildingDetails)

        val name = intent.getStringExtra("BUILDING_NAME")
        val details = intent.getStringExtra("BUILDING_DETAILS")
        val imageResId = intent.getIntExtra("BUILDING_IMAGE", 0)

        buildingImage.setImageResource(imageResId)
        buildingName.text = name
        buildingDetails.text = details
    }
}
