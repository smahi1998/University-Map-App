package edu.okcu.mapdemo

data class Building(val name: String, val details: String, val imageResId: Int) {


    }

