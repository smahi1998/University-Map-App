package edu.okcu.mapdemo

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class BuildingAdapter(private val buildings: List<Building>, private val clickListener: (Building) -> Unit) :
    RecyclerView.Adapter<BuildingAdapter.BuildingViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BuildingViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_building, parent, false)
        return BuildingViewHolder(view)
    }

    override fun onBindViewHolder(holder: BuildingViewHolder, position: Int) {
        holder.bind(buildings[position], clickListener)
    }

    override fun getItemCount() = buildings.size

    class BuildingViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val nameTextView: TextView = itemView.findViewById(R.id.buildingName)

        fun bind(building: Building, clickListener: (Building) -> Unit) {
            nameTextView.text = building.name
            itemView.setOnClickListener { clickListener(building) }
        }
    }
}
